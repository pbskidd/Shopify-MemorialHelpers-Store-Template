/**
 * IE8 max-width bug: a generic fix for images
 * ===========================================
 * 
 * When the size of a replaced element is controlled by CSS rules for width and
 * max-width, the browser has to rescale the element. Ie, it has to adjust both
 * width and height according to the intrinsic aspect ratio of the element.
 * 
 * IE8 does not rescale replaced elements correctly when a max-width limit is
 * binding.
 * 
 * This script uses jQuery to fix the problem for the most affected element
 * type, images. It corrects the height of the affected images by setting an
 * appropriate max-height.
 * 
 * ## Usage:
 * 
 * Usage is simple. Put a conditional comment targeting IE8 in your page source.
 * Within it, load a copy of the jQuery library if it isn't available already,
 * then load this script. That's all there is to it.
 * 
 * <!--[if IE 8]>
 *   <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js" type="text/javascript"></script>
 *   <script src="[YOUR PATH HERE]/ie8_fix_maxwidth.js" type="text/javascript"></script>
 * <![endif]-->
 *
 * ## Dependencies:
 *
 * jQuery 1.6.1 or newer. Will also work with older versions - ymmv.
 *
 * (The test suite requires jQuery >= 1.6.1, so the script is not unit tested
 * with older versions.)
 * 
 * ## Limitations:
 *
 * None, AFAICT, with regard to IE8. Note that the script will cause distortions
 * in IE6, 7 and 9 if it is not enclosed in a conditional comment targeting IE8.
 * (These distortions could be avoided, but at a computational cost. Use the
 * comment.)
 *
 * See the test suite for currently supported scenarios:
 * http://www.zeilenwechsel.de/it/code/get/ie8-max-width-fix/tests/ie8_fix_maxwidth.html
 *
 * ## Other:
 * 
 * Tested with jQuery 1.6.1, 1.6.2
 *
 * @author  Michael Heim, http://www.zeilenwechsel.de/
 * @license MIT, http://www.opensource.org/licenses/mit-license.php
 * @version 0.3.0, 13 July 2011
 */

$(function(){if(document.documentElement&&document.documentElement.currentStyle&&document.documentElement.runtimeStyle){var t=function(t){var e=$(t),n=e.height(),i=t.currentStyle.width;if(/^[\d.]+(px)?$/i.test(i))i=parseInt(i,10);else if(/^\d/.test(i)){var r=t.style.left,l=t.runtimeStyle.left;t.runtimeStyle.left=t.currentStyle.left,t.style.left=i||0,i=t.style.pixelLeft,t.style.left=r,t.runtimeStyle.left=l}if(i&&n){var h=n/i,u=e.css("max-width"),c=Math.round(parseFloat(u)*h)+u.match(/[\d.]+([^\d.]*)$/)[1];e.css("max-height",c),/[\d.]+%/.test(t.currentStyle.maxWidth)&&e.resize(function(){u=e.css("max-width"),c=Math.round(parseFloat(u)*h)+u.match(/[\d.]+([^\d.]*)$/)[1],e.css("max-height",c)})}};$("img").filter(function(){var t="auto"!==this.currentStyle.width&&"inherit"!==this.currentStyle.width&&"auto"===this.currentStyle.height&&"none"!==this.currentStyle.maxWidth&&"none"===this.currentStyle.maxHeight;return t}).each(function(){$(this).load(function(){t(this)}),this.complete&&t(this)})}});